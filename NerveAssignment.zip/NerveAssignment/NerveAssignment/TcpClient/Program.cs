﻿
using System.Net.Sockets;
using System.Text;

Console.Write("Enter Server IP: ");
string serverIp = Console.ReadLine() ?? "127.0.0.1";

Console.Write("Enter Port: ");
int port = int.Parse(Console.ReadLine() ?? "5000");

using TcpClient client = new TcpClient();

await client.ConnectAsync(serverIp, port);


Console.WriteLine("Connected to Server!");

NetworkStream stream = client.GetStream();

using var writer = new StreamWriter(
    stream, Encoding.UTF8, leaveOpen: true)
{
    AutoFlush = true
};

using var reader = new StreamReader(
    stream, Encoding.UTF8, leaveOpen: true);

Console.Write("Enter message: ");

string message = Console.ReadLine() ?? "";

string encryptedMessage = EncryptionHelper.Encrypt(message);

await writer.WriteLineAsync(encryptedMessage);

Console.WriteLine("Server Response:");

string? response;

while ((response = await reader.ReadLineAsync()) != null)
{
    string decryptedResponse = EncryptionHelper.Decrypt(response);

    Console.WriteLine(decryptedResponse);
}
