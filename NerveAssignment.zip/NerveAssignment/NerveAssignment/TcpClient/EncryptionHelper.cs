﻿
using System.Security.Cryptography;
using System.Text;

public static class EncryptionHelper
{
    private static readonly byte[] Key =
        Encoding.UTF8.GetBytes(
            "0123456789ABCDEF0123456789ABCDEF");

    public static string Encrypt(string plainText)
    {
        byte[] nonce = RandomNumberGenerator.GetBytes(12);
        byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
        byte[] cipherBytes = new byte[plainBytes.Length];
        byte[] tag = new byte[16];

        using (AesGcm aes = new AesGcm(Key, 16))
        {
            aes.Encrypt(nonce, plainBytes, cipherBytes, tag);
        }

        byte[] result = nonce.Concat(cipherBytes)
                             .Concat(tag).ToArray();

        return Convert.ToBase64String(result);
    }

    public static string Decrypt(string encryptedText)
    {
        byte[] data = Convert.FromBase64String(encryptedText);

        byte[] nonce = data.Take(12).ToArray();
        byte[] tag = data.Skip(data.Length - 16).ToArray();
        byte[] cipherBytes = data.Skip(12)
                                 .Take(data.Length - 28).ToArray();

        byte[] plainBytes = new byte[cipherBytes.Length];

        using (AesGcm aes = new AesGcm(Key, 16))
        {
            aes.Decrypt(nonce, cipherBytes, tag, plainBytes);
        }

        return Encoding.UTF8.GetString(plainBytes);
    }
}
