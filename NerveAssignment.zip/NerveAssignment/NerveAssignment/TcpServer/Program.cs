﻿
using System.Net;
using System.Net.Sockets;
using System.Text;

Console.Write("Enter Server Port: ");
int port = int.Parse(Console.ReadLine() ?? "5000");

TcpListener server = new TcpListener(IPAddress.Any, port);

server.Start();

var collection = new Dictionary<string, Dictionary<string, int>>
{
    ["SetA"] = new() { ["One"] = 1, ["Two"] = 2 },
    ["SetB"] = new() { ["Three"] = 3, ["Four"] = 4 },
    ["SetC"] = new() { ["Five"] = 5, ["Six"] = 6 },
    ["SetD"] = new() { ["Seven"] = 7, ["Eight"] = 8 },
    ["SetE"] = new() { ["Nine"] = 9, ["Ten"] = 10 }
};

Console.WriteLine($"Server started on port {port}");
Console.WriteLine("Waiting for client...");

while (true)
{
    TcpClient client = await server.AcceptTcpClientAsync();

    _ = Task.Run(async () =>
    {
        using (client)
        {
            NetworkStream stream = client.GetStream();

            using var reader = new StreamReader(
                stream, Encoding.UTF8, leaveOpen: true);

            using var writer = new StreamWriter(
                stream, Encoding.UTF8, leaveOpen: true)
            {
                AutoFlush = true
            };

            string? encryptedMessage = await reader.ReadLineAsync();

            if (string.IsNullOrWhiteSpace(encryptedMessage))
                return;

            string message = EncryptionHelper.Decrypt(encryptedMessage);

            if (string.IsNullOrWhiteSpace(message))
                return;

            Console.WriteLine("Received: " + message);

            string[] parts = message.Split('-', 2);

            if (parts.Length != 2 ||
                !collection.ContainsKey(parts[0]) ||
                !collection[parts[0]].ContainsKey(parts[1]))
            {
                await writer.WriteLineAsync(EncryptionHelper.Encrypt("EMPTY"));
                return;
            }

            int value = collection[parts[0]][parts[1]];

            Console.WriteLine("Value found: " + value);

            for (int i = 0; i < value; i++)
            {
                string currentTime =
                    DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");

                string encryptedResponse = EncryptionHelper.Encrypt(currentTime);

                await writer.WriteLineAsync(encryptedResponse);

                if (i < value - 1)
                    await Task.Delay(1000);
            }
        }
    });
}
